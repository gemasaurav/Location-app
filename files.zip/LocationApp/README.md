# Location — Android source project

## What this app does

Tap "Get My Location" and it shows:
1. Area (suburb/neighbourhood/locality)
2. District
3. State
4. Country
5. Continent
6. Nearest Railway Station (name + distance)
7. Nearest Airport (name + distance)
8. Prime Area to Travel Nearby (a notable tourist attraction, name + distance)
9. Nearest Big/Famous Area Nearby (a well-known town/city landmark, name + distance)
10. "Open in Maps" button — opens your phone's map app centered on your exact coordinates

All data comes from free, no-signup OpenStreetMap services:
- **Nominatim** — reverse geocoding (address details: area/district/state/country)
- **Overpass API** — nearest railway station, airport, attraction, and big nearby locality

Continent is derived locally from the country code Nominatim returns (there's a
built-in country→continent lookup table in `ContinentLookup.kt`).

## A note on what's not included

There's no free, public dataset anywhere that maps exact police jurisdiction
boundaries to a location — so that item was replaced with "Nearest Big/Famous
Area Nearby" instead, which is genuinely available from open map data.

## How to build this into an installable APK — same GitHub Actions routine as before

1. Zip this whole `LocationApp` folder (or use the zip provided alongside this README).
2. Create a new GitHub repo (e.g. `location-app`).
3. Upload the zip as a single file (name it `files.zip` to match the workflow below,
   or adjust the workflow's `unzip -o files.zip` line to match your filename).
4. Add `.github/workflows/build.yml` with the content provided alongside this README.
5. Push → go to the **Actions** tab → wait for the green checkmark →
   download the APK from **Artifacts** → extract → install.

This project already includes a fixed debug keystore (`app/keystore/debug.keystore`)
so every future rebuild keeps the same signature — you can just install updates
directly over the old version without uninstalling first.

## Permissions

The app asks for location permission (fine + coarse) the first time you tap
"Get My Location". If you deny it, tap the button again to be asked once more,
or enable it manually via Settings → Apps → Location → Permissions.
