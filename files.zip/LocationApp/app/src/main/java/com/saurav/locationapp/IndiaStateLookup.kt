package com.saurav.locationapp

/**
 * Nominatim sometimes leaves the "state" address field blank for Delhi and a
 * few Union Territories, but still returns an ISO3166-2-lvl4 code like
 * "IN-DL" at the top level of the response. This maps that code to a proper
 * state/UT name so we always have something sensible to show.
 */
object IndiaStateLookup {

    private val isoToName: Map<String, String> = mapOf(
        "in-dl" to "Delhi",
        "in-up" to "Uttar Pradesh",
        "in-mh" to "Maharashtra",
        "in-ka" to "Karnataka",
        "in-tn" to "Tamil Nadu",
        "in-wb" to "West Bengal",
        "in-rj" to "Rajasthan",
        "in-gj" to "Gujarat",
        "in-mp" to "Madhya Pradesh",
        "in-br" to "Bihar",
        "in-ap" to "Andhra Pradesh",
        "in-ts" to "Telangana",
        "in-kl" to "Kerala",
        "in-pb" to "Punjab",
        "in-hr" to "Haryana",
        "in-jh" to "Jharkhand",
        "in-as" to "Assam",
        "in-or" to "Odisha",
        "in-cg" to "Chhattisgarh",
        "in-uk" to "Uttarakhand",
        "in-hp" to "Himachal Pradesh",
        "in-jk" to "Jammu and Kashmir",
        "in-la" to "Ladakh",
        "in-go" to "Goa",
        "in-tr" to "Tripura",
        "in-ml" to "Meghalaya",
        "in-mn" to "Manipur",
        "in-nl" to "Nagaland",
        "in-mz" to "Mizoram",
        "in-ar" to "Arunachal Pradesh",
        "in-sk" to "Sikkim",
        "in-ch" to "Chandigarh",
        "in-py" to "Puducherry",
        "in-an" to "Andaman and Nicobar Islands",
        "in-dn" to "Dadra and Nagar Haveli and Daman and Diu",
        "in-ld" to "Lakshadweep"
    )

    fun nameForIsoCode(isoCode: String?): String? {
        if (isoCode.isNullOrBlank()) return null
        return isoToName[isoCode.lowercase()]
    }
}
