package com.saurav.locationapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private lateinit var btnGetLocation: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var tvStatus: TextView
    private lateinit var resultCard: CardView
    private lateinit var tvArea: TextView
    private lateinit var tvDistrict: TextView
    private lateinit var tvState: TextView
    private lateinit var tvCountry: TextView
    private lateinit var tvContinent: TextView
    private lateinit var tvRailway: TextView
    private lateinit var tvAirport: TextView
    private lateinit var tvAttraction: TextView
    private lateinit var tvFamousArea: TextView
    private lateinit var btnOpenMaps: Button

    private var currentLat: Double = 0.0
    private var currentLon: Double = 0.0

    private val locationPermissionRequestCode = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnGetLocation = findViewById(R.id.btnGetLocation)
        progressBar = findViewById(R.id.progressBar)
        tvStatus = findViewById(R.id.tvStatus)
        resultCard = findViewById(R.id.resultCard)
        tvArea = findViewById(R.id.tvArea)
        tvDistrict = findViewById(R.id.tvDistrict)
        tvState = findViewById(R.id.tvState)
        tvCountry = findViewById(R.id.tvCountry)
        tvContinent = findViewById(R.id.tvContinent)
        tvRailway = findViewById(R.id.tvRailway)
        tvAirport = findViewById(R.id.tvAirport)
        tvAttraction = findViewById(R.id.tvAttraction)
        tvFamousArea = findViewById(R.id.tvFamousArea)
        btnOpenMaps = findViewById(R.id.btnOpenMaps)

        btnGetLocation.setOnClickListener { checkPermissionAndFetch() }
        btnOpenMaps.setOnClickListener { openInMaps() }
    }

    private fun checkPermissionAndFetch() {
        val hasPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            fetchLocation()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                locationPermissionRequestCode
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationPermissionRequestCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                fetchLocation()
            } else {
                Toast.makeText(this, getString(R.string.permission_needed), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun fetchLocation() {
        resultCard.visibility = View.GONE
        progressBar.visibility = View.VISIBLE
        tvStatus.text = getString(R.string.fetching)

        val hasPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasPermission) return

        val client = LocationServices.getFusedLocationProviderClient(this)
        client.lastLocation
            .addOnSuccessListener { location ->
                if (location != null) {
                    currentLat = location.latitude
                    currentLon = location.longitude
                    loadAllDetails(currentLat, currentLon)
                } else {
                    progressBar.visibility = View.GONE
                    tvStatus.text = "Couldn't get a location fix. Make sure GPS/location is turned on and try again."
                }
            }
            .addOnFailureListener {
                progressBar.visibility = View.GONE
                tvStatus.text = "Failed to get location: ${it.message}"
            }
    }

    private fun loadAllDetails(lat: Double, lon: Double) {
        Thread {
            var area = getString(R.string.not_found)
            var district = getString(R.string.not_found)
            var state = getString(R.string.not_found)
            var country = getString(R.string.not_found)
            var continent = "Unknown"
            var railway = getString(R.string.not_found)
            var airport = getString(R.string.not_found)
            var attraction = getString(R.string.not_found)
            var famousArea = getString(R.string.not_found)

            // 1. Reverse geocode via Nominatim (OpenStreetMap) for address components
            try {
                val url = URL(
                    "https://nominatim.openstreetmap.org/reverse?format=json&lat=$lat&lon=$lon&zoom=16&addressdetails=1"
                )
                val conn = url.openConnection() as HttpURLConnection
                conn.setRequestProperty("User-Agent", "SauravLocationApp/1.0")
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(body)
                    val addr = json.optJSONObject("address")
                    if (addr != null) {
                        area = firstNonBlank(
                            addr.optString("suburb"), addr.optString("neighbourhood"),
                            addr.optString("village"), addr.optString("town"),
                            addr.optString("city_district"), addr.optString("city")
                        )
                        district = firstNonBlank(
                            addr.optString("state_district"), addr.optString("county")
                        )
                        state = addr.optString("state", getString(R.string.not_found))
                        country = addr.optString("country", getString(R.string.not_found))
                        val countryCode = addr.optString("country_code", "")
                        continent = ContinentLookup.continentFor(countryCode)
                    }
                }
                conn.disconnect()
            } catch (e: Exception) {
                // leave defaults ("Not found nearby") if this fails
            }

            // 2. Nearest railway station (within 30 km)
            railway = nearestOverpassPlace(lat, lon, "node[\"railway\"=\"station\"]", 30000)
            // 3. Nearest airport (within 150 km, since airports are sparse)
            airport = nearestOverpassPlace(lat, lon, "node[\"aeroway\"=\"aerodrome\"]", 150000)
            // 4. A notable nearby tourist attraction
            attraction = nearestOverpassPlace(lat, lon, "node[\"tourism\"=\"attraction\"]", 15000)
            // 5. Nearest well-known big locality/town/city nearby (useful as a landmark reference)
            famousArea = nearestOverpassPlace(lat, lon, "node[\"place\"~\"^(city|town)$\"]", 60000)

            val finalArea = area; val finalDistrict = district; val finalState = state
            val finalCountry = country; val finalContinent = continent
            val finalRailway = railway; val finalAirport = airport
            val finalAttraction = attraction; val finalFamousArea = famousArea

            runOnUiThread {
                progressBar.visibility = View.GONE
                tvStatus.text = ""
                tvArea.text = finalArea
                tvDistrict.text = finalDistrict
                tvState.text = finalState
                tvCountry.text = finalCountry
                tvContinent.text = finalContinent
                tvRailway.text = finalRailway
                tvAirport.text = finalAirport
                tvAttraction.text = finalAttraction
                tvFamousArea.text = finalFamousArea
                resultCard.visibility = View.VISIBLE
            }
        }.start()
    }

    /**
     * Queries the Overpass API (OpenStreetMap) for elements matching [tagFilter] within
     * [radiusMeters] of (lat, lon), then returns the closest one by straight-line distance
     * along with that distance, e.g. "Palam Railway Station (2.3 km)".
     */
    private fun nearestOverpassPlace(lat: Double, lon: Double, tagFilter: String, radiusMeters: Int): String {
        return try {
            val query = "[out:json][timeout:15];($tagFilter(around:$radiusMeters,$lat,$lon););out center 20;"
            val encodedQuery = URLEncoder.encode(query, "UTF-8")
            val url = URL("https://overpass-api.de/api/interpreter?data=$encodedQuery")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 15000
            conn.readTimeout = 15000

            if (conn.responseCode != 200) {
                conn.disconnect()
                return getString(R.string.not_found)
            }

            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val json = JSONObject(body)
            val elements = json.optJSONArray("elements") ?: JSONArray()

            var bestName: String? = null
            var bestDistanceKm = Double.MAX_VALUE

            for (i in 0 until elements.length()) {
                val el = elements.getJSONObject(i)
                val tags = el.optJSONObject("tags")
                val name = tags?.optString("name", "")?.takeIf { it.isNotBlank() } ?: continue
                val elLat = el.optDouble("lat", Double.NaN)
                val elLon = el.optDouble("lon", Double.NaN)
                if (elLat.isNaN() || elLon.isNaN()) continue

                val distanceKm = haversineKm(lat, lon, elLat, elLon)
                if (distanceKm < bestDistanceKm) {
                    bestDistanceKm = distanceKm
                    bestName = name
                }
            }

            if (bestName != null) {
                val roundedKm = String.format("%.1f", bestDistanceKm)
                "$bestName ($roundedKm km)"
            } else {
                getString(R.string.not_found)
            }
        } catch (e: Exception) {
            getString(R.string.not_found)
        }
    }

    private fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0 // Earth radius in km
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    private fun firstNonBlank(vararg values: String?): String {
        for (v in values) {
            if (!v.isNullOrBlank()) return v
        }
        return getString(R.string.not_found)
    }

    private fun openInMaps() {
        if (currentLat == 0.0 && currentLon == 0.0) {
            Toast.makeText(this, "Get your location first", Toast.LENGTH_SHORT).show()
            return
        }
        val uri = Uri.parse("geo:$currentLat,$currentLon?q=$currentLat,$currentLon")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            // Fall back to opening Google Maps in a browser if no maps app is installed
            val browserUri = Uri.parse("https://www.google.com/maps?q=$currentLat,$currentLon")
            startActivity(Intent(Intent.ACTION_VIEW, browserUri))
        }
    }
}
