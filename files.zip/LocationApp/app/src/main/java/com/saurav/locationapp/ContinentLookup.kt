package com.saurav.locationapp

/**
 * Maps ISO 3166-1 alpha-2 country codes (as returned by OpenStreetMap/Nominatim)
 * to their continent. Nominatim doesn't return continent directly, so we derive
 * it from the country code it gives us.
 */
object ContinentLookup {

    private val countryToContinent: Map<String, String> = mapOf(
        // Asia
        "in" to "Asia", "cn" to "Asia", "jp" to "Asia", "kr" to "Asia", "kp" to "Asia",
        "id" to "Asia", "pk" to "Asia", "bd" to "Asia", "lk" to "Asia", "np" to "Asia",
        "bt" to "Asia", "mv" to "Asia", "mm" to "Asia", "th" to "Asia", "vn" to "Asia",
        "kh" to "Asia", "la" to "Asia", "my" to "Asia", "sg" to "Asia", "ph" to "Asia",
        "bn" to "Asia", "tl" to "Asia", "mn" to "Asia", "kz" to "Asia", "kg" to "Asia",
        "tj" to "Asia", "tm" to "Asia", "uz" to "Asia", "af" to "Asia", "ir" to "Asia",
        "iq" to "Asia", "sy" to "Asia", "lb" to "Asia", "jo" to "Asia", "il" to "Asia",
        "ps" to "Asia", "sa" to "Asia", "ye" to "Asia", "om" to "Asia", "ae" to "Asia",
        "qa" to "Asia", "bh" to "Asia", "kw" to "Asia", "tr" to "Asia", "cy" to "Asia",
        "ge" to "Asia", "am" to "Asia", "az" to "Asia", "tw" to "Asia", "hk" to "Asia",
        "mo" to "Asia",

        // Europe
        "gb" to "Europe", "ie" to "Europe", "fr" to "Europe", "de" to "Europe",
        "es" to "Europe", "pt" to "Europe", "it" to "Europe", "ch" to "Europe",
        "at" to "Europe", "be" to "Europe", "nl" to "Europe", "lu" to "Europe",
        "dk" to "Europe", "no" to "Europe", "se" to "Europe", "fi" to "Europe",
        "is" to "Europe", "pl" to "Europe", "cz" to "Europe", "sk" to "Europe",
        "hu" to "Europe", "ro" to "Europe", "bg" to "Europe", "gr" to "Europe",
        "hr" to "Europe", "si" to "Europe", "ba" to "Europe", "rs" to "Europe",
        "me" to "Europe", "mk" to "Europe", "al" to "Europe", "xk" to "Europe",
        "md" to "Europe", "ua" to "Europe", "by" to "Europe", "ru" to "Europe",
        "lt" to "Europe", "lv" to "Europe", "ee" to "Europe", "mt" to "Europe",
        "li" to "Europe", "mc" to "Europe", "sm" to "Europe", "va" to "Europe",
        "ad" to "Europe",

        // Africa
        "ng" to "Africa", "eg" to "Africa", "za" to "Africa", "ke" to "Africa",
        "et" to "Africa", "gh" to "Africa", "tz" to "Africa", "ug" to "Africa",
        "dz" to "Africa", "ma" to "Africa", "tn" to "Africa", "ly" to "Africa",
        "sd" to "Africa", "ss" to "Africa", "cm" to "Africa", "ci" to "Africa",
        "sn" to "Africa", "ml" to "Africa", "ne" to "Africa", "bf" to "Africa",
        "zw" to "Africa", "zm" to "Africa", "mz" to "Africa", "mg" to "Africa",
        "ao" to "Africa", "cd" to "Africa", "cg" to "Africa", "ga" to "Africa",
        "na" to "Africa", "bw" to "Africa", "rw" to "Africa", "bi" to "Africa",
        "so" to "Africa", "dj" to "Africa", "er" to "Africa", "tg" to "Africa",
        "bj" to "Africa", "sl" to "Africa", "lr" to "Africa", "gn" to "Africa",
        "gw" to "Africa", "gm" to "Africa", "mr" to "Africa", "td" to "Africa",
        "cf" to "Africa", "gq" to "Africa", "sc" to "Africa", "mu" to "Africa",
        "km" to "Africa", "cv" to "Africa", "sz" to "Africa", "ls" to "Africa",
        "st" to "Africa",

        // North America
        "us" to "North America", "ca" to "North America", "mx" to "North America",
        "gt" to "North America", "bz" to "North America", "sv" to "North America",
        "hn" to "North America", "ni" to "North America", "cr" to "North America",
        "pa" to "North America", "cu" to "North America", "jm" to "North America",
        "ht" to "North America", "do" to "North America", "bs" to "North America",
        "tt" to "North America", "bb" to "North America", "gd" to "North America",
        "lc" to "North America", "vc" to "North America", "ag" to "North America",
        "dm" to "North America", "kn" to "North America",

        // South America
        "br" to "South America", "ar" to "South America", "cl" to "South America",
        "co" to "South America", "pe" to "South America", "ve" to "South America",
        "ec" to "South America", "bo" to "South America", "py" to "South America",
        "uy" to "South America", "gy" to "South America", "sr" to "South America",

        // Oceania
        "au" to "Oceania", "nz" to "Oceania", "fj" to "Oceania", "pg" to "Oceania",
        "sb" to "Oceania", "vu" to "Oceania", "ws" to "Oceania", "to" to "Oceania",
        "ki" to "Oceania", "fm" to "Oceania", "mh" to "Oceania", "pw" to "Oceania",
        "nr" to "Oceania", "tv" to "Oceania"
    )

    fun continentFor(countryCode: String?): String {
        if (countryCode.isNullOrBlank()) return "Unknown"
        return countryToContinent[countryCode.lowercase()] ?: "Unknown"
    }
}
